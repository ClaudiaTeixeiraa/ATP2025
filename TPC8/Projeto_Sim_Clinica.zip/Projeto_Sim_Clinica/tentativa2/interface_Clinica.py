import FreeSimpleGUI as sg
import time
import Simulacao as App2
import Triagem 
import Consultorios as con
import Graficos as gr

#-------FICHEIRO PARA A INTERFACE DA CLÍNICA EM SI

# ----------------------------
# CORES E FONTES
# ----------------------------
PRIMARY = "#429c91"
HEADER_BG = "#6f7f8f"
BG = "#f2f2f2"
OCUPADO = "#d15050"
LIVRE = PRIMARY
CADEIRA_LIVRE = "#9aa3ad"
CADEIRA_OCUPADA = "red"

ALUMINIO = "#6e747a"   #estrutura 
VIDRO = "#e6f2fa"      #vidro

FONT_TITLE = ("Inter", 18, "bold")
FONT_BUTTON = ("Inter", 10)




def simulacao_principal(config_atual):

    balcoes = Triagem.criaBalcoes(config_atual)

    sg.set_options(
        background_color=BG,
        element_background_color=BG,
        text_color="black",
        font=FONT_BUTTON
    )


    def define_Mapa_Balcoes(balcoes):
        MAPA_BALCOES = {}
        contador_balcoes = 1
        contador_balcoes_prior= 1

        for ind,balcao in enumerate(balcoes):

            if balcao["prioritario"] == True:
                key = f"-BP{contador_balcoes_prior}-"
                contador_balcoes_prior +=1

            elif balcao["prioritario"] == False:
                key = f"-B{contador_balcoes}-"
                contador_balcoes +=1

            MAPA_BALCOES[key] = ind

        return MAPA_BALCOES


    MAPA_BALCOES = define_Mapa_Balcoes(balcoes)


    sg.set_options(
        background_color=BG,
        element_background_color=BG,
        text_color="black",
        font=FONT_BUTTON
    )
    # ----------------------------
    # HEADER
    
    header = [
        sg.Text(
            "CLÍNICA SAÚDE",
            font=FONT_TITLE,
            text_color="white",
            background_color="#407B7B",
            justification="center",
            expand_x=True,
            pad=(0, 0)
        )
    ]

    # ----------------------------
    # ELEMENTOS NA COLUNA À ESQUERDA

    def criaFrame_balcoes(balcoes,MAPA_BALCOES):
        lista_botoes = []
        contador_balcoes_prior = 1
        contador_balcoes =1
        lista_keys = list(MAPA_BALCOES.keys())

        for ind,balcao in enumerate(balcoes):
            key = lista_keys[ind]
            if balcao["prioritario"]:
                lista_botoes.append([sg.Button(f"Balcão Prioritário{str(contador_balcoes_prior)}", key = key, size=(18, 2), button_color=("white", PRIMARY),pad=(15, 3))])
                contador_balcoes_prior +=1
            
            elif not balcao["prioritario"]:
                lista_botoes.append([sg.Button(f"Balcão{str(contador_balcoes)}", key=key, size=(18, 2), button_color=("white", PRIMARY),pad=(15, 3))])
                contador_balcoes +=1

        return lista_botoes
    lista_botoes = criaFrame_balcoes(balcoes,MAPA_BALCOES)
    lista_botoes.append([sg.Button("Tempo fila triagem", key="-TWAIT-", size=(9, 2), button_color=("white", CADEIRA_LIVRE), font=FONT_BUTTON),
                        sg.Button("Tempo fila consulta", key="-CWAIT-", size=(9, 2), button_color=("white", CADEIRA_LIVRE), font= FONT_BUTTON)])
    rececao = sg.Frame("RECEÇÃO CLÍNICA", lista_botoes, title_color= PRIMARY)
    

    tempo_display = sg.Text(
        "⏱ Relógio: 00:00",
        key="-TEMPO-",
        font=("Inter", 12, "bold"),
        text_color="white",
        background_color=PRIMARY,
        justification="center",
        size=(20, 1),
        pad=(10, 5)
    )

    botao_pausa = sg.Button(
        "⏸ Pausar a simulação",
        key="-PAUSA-",
        font=("Inter", 10, "bold"),
        size=(25, 1),
        button_color=("white", "#6e747a"),
        pad=(10, 10)
    )
    
    botao_avanca = sg.Button(
        "⏩ Executar até ao fim",
        key="-FAST-",
        font=("Inter", 10, "bold"),
        size=(25,1),
        button_color=("white", "#429c91"),
        pad=(10, 10)
    )

    # ----------------------------
    # SALA DE ESPERA - 2ª coluna
    
    def cadeiras(linhas=4, colunas=6):
        cadeiras = []
        for i in range(linhas):
            row = []
            for j in range(colunas):
                cadeira = sg.Text(
                    "",
                    size=(2, 1),
                    background_color=CADEIRA_LIVRE,
                    pad=(6, 5),
                    key=f"-CADEIRA-{i}-{j}-"
                )
                row.append(cadeira)
                cadeiras.append(cadeira)
            yield row, cadeiras
            
            
    linhas = []
    CADEIRAS = []

    for row, lista in cadeiras():
        linhas.append(row)
        CADEIRAS = lista

    sala_espera = sg.Frame(
        "SALA DE ESPERA - CADEIRAS",
        linhas,
        key="-SALA-",
        title_color=PRIMARY,
        background_color="white",
        pad=(10, 10)
    )

    # ----------------------------
    # PORTAS AUTOMÁTICAS (VIDRO)
    # ----------------------------
    def patio_entrada():
        return sg.Frame(
            "ENTRADA PRINCIPAL",
            [
                [
                    sg.Text("", key="-PORTA_ESQ-", size=(12, 4),
                            background_color=VIDRO, pad=(0, 0)),
                    sg.Text("", key="-ABERTURA-", size=(0, 4),
                            background_color=BG, pad=(0, 0)),
                    sg.Text("", key="-PORTA_DIR-", size=(12, 4),
                            background_color=VIDRO, pad=(0, 0)),
                ]
            ],
            key="-PATIO-",
            background_color=ALUMINIO,
            title_color="white",
            relief=sg.RELIEF_FLAT,   # sem contorno preto
            pad=(10, 5)
        )

    # ----------------------------
    # CONSULTÓRIOS - 3ª coluna
    # ----------------------------
    consultorios = sg.Frame(
        "CONSULTÓRIOS",
        [
            [
                sg.Button("Neurologia", key="-CONS-s7-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
                sg.Button("Gastroentereologia", key="-CONS-s2-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
                sg.Button("Pneumonologia", key="-CONS-s3-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
            ],
            [ sg.Button("Psiquiatria", key="-CONS-s9-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
                sg.Button("Dermatologia", key="-CONS-s1-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
                sg.Button("Endocrinologia", key="-CONS-s5-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10))
            ],
            [   
                sg.Button("Pediatria", key="-CONS-s10-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
                sg.Button("Medicina Geral", key="-CONS-s11-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
                sg.Button("Ortopedia", key="-CONS-s6-",size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
            ],
            [
                sg.Text("ENTRADA NOS CONSULTÓRIOS", size=(18, 3) ,text_color="white", justification="center", background_color="#9aa3ad", font=("Inter", 11, "bold"),pad=(3,10)),
                sg.Button("Cardiologia",key="-CONS-s4-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10)),
                sg.Button("Ginecologia\nObstetrícia", key="-CONS-s8-", size=(18, 3), button_color=("white", PRIMARY), font=("Inter", 11, "bold"), pad=(3, 10))
            ]
        ],
        title_color=PRIMARY,
        expand_x=True,
        expand_y=True,
        background_color="white"
    )

    # ----------------------------
    # LAYOUT
    
    
    layout = [
        header,
        [
            sg.Column([[rececao]], vertical_alignment="top",background_color="white"),
            
            sg.Column(
                [
                    [sala_espera],
                    [tempo_display],
                    [botao_pausa],
                    [patio_entrada()],
                    [botao_avanca]
                ],
                vertical_alignment="top",
                expand_x=True,
                expand_y=True, 
                background_color="white"
            ),
            sg.Column([[consultorios]], vertical_alignment="top", expand_x=True, background_color="white"), 

        ]
    ]



    #-------FORMATAR O TEMPORIZADOR (de minutos para horas:minutos)-------
    def formatar_tempo(minutos_desde_inicio, hora_inicio=9, minuto_inicio=0):
        total_minutos = hora_inicio * 60 + minuto_inicio + minutos_desde_inicio
        h = int(total_minutos // 60)
        m = int(total_minutos % 60)
        return f"{h:02d}:{m:02d}"


    #-------------OBTER CONSULTÓRIOS A PARTIR DE SECCOES----------
    def consultorios_por_especialidade(seccoes):
        mapa = {}
        for sec in seccoes:
            mapa[sec["id"]] = sec["consultorios"]
        return mapa


    #------------ TEMPO DE OCUPAÇÃO DO CONSULTÓRIO ------------------
    def tempo_ocupacao(inicio):
        if inicio is None:
            return "—"
        minutos = int((time.time() - inicio) / 60)
        return f"{minutos} min"


    #------------------VERIFICAR SE O CONSULTÓRIO ESTÁ LIVRE 
    def em_consulta(med,t_atual):
        return medico_em_turno(med,t_atual) and med.get("doente") is not None
    #quer dizer que o médico está em turno E tem doente
    
    
    # ---------------------------- ESTADO E CORES DOS CONSULTÓRIOS
    def cor_consultorio(med, t_atual):
        if em_consulta(med, t_atual):
            return OCUPADO
        elif not medico_em_turno(med, t_atual):
            return  "#9aa3ad"  #fora de turno
        else:
            return LIVRE
        
    
    #-------------------VERIFICAR SE O MÉDICO ESTÁ NO SEU TURNO---------------
    def medico_em_turno(med,t_atual):
        inicio = med.get("inicio_turno", 0)
        fim = med.get("fim_turno", 720)
        return inicio <= t_atual < fim
        
        

    #----------------------TERMINAR SIMULAÇÃO
    def executar_simulacao_completa(config_atual):
        simulador = App2.simulação(config_atual)
        try:
            while True:
                next(simulador)
        except StopIteration as e:
            return e.value  #isto devolve o dicionário final


        
    #-------------FORMATAR A JANELA QUE SURGE DEPOIS DE CLICAR NUMA ESPECIALIDADE-----------
    def popup_escolher_consultorio(consultorios,t_atual):
        layout = [
        [sg.Text("Escolha o consultório", font=FONT_TITLE, text_color="white", background_color=CADEIRA_LIVRE)],
        [sg.HorizontalSeparator()]
        ]

        for cons in consultorios:
            med = cons["medico"]

            if not medico_em_turno(med,t_atual):
                estado = "Fora de turno"
                cor = "#9aa3ad"
            elif em_consulta(med,t_atual):
                estado = "Ocupado"
                cor = OCUPADO
            else:
                estado = "Livre"
                cor = LIVRE
                
                
            layout.append([
                sg.Button(
                    f"Consultório {cons['id']}\n{estado}",
                    key=cons["id"],
                    size=(25, 2),
                    font=("Inter", 13, "bold"),
                    button_color=("white", cor),
                    disabled=False 
                )
            ])

        popup = sg.Window(
            "Consultórios",
            layout,
            modal=True,
            finalize=True,
            background_color=BG
        )
        while True:
            event, _ = popup.read()
            if event in (sg.WINDOW_CLOSED, None):
                popup.close()
                return None
            
            popup.close()
            return event
        
        
    #-------------------------FORMATAR POP UP DEPOIS DE CLICAR NO CONSULTÓRIO--------
    def popup_info_consultorio(med, cons, t_atual):
        nome_doente = med.get("doente")["nome"] if med.get("doente") else "—"
        inicio = med.get("inicio_consulta")
        tempo = t_atual - inicio if inicio is not None else 0

        BG_CUTE = "#5b938d"  
        FONT_INFO = ("Inter", 10,"bold")

        frame_layout = [
            [sg.Text(f"Médico: {med['nome']}", font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
            [sg.Text(f"Especialidade: {med['especialidade']}", font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
            [sg.Text(f"Consultório: {cons['id']}", font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
            [sg.Text(f"Doente: {nome_doente}", font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
            [sg.Text(f"Tempo de consulta: {round(tempo,2)} min", font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
            [sg.Text(f"Estado: {'Fora de turno' if not medico_em_turno(med,t_atual) else 'Ocupado' if em_consulta(med,t_atual) else 'Livre'}",
                    font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
            [sg.Text(f"Doentes atendidos: {med['ndoentes_atendidos']}", font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
            [sg.Text(f"Tempo total ocupado: {med['tempo_ocupado']} min", font=FONT_INFO, text_color=BG_CUTE, background_color="white")],
        ]


        layout = [
            [sg.Frame(title="", layout=frame_layout, background_color="white", pad=(10,10))],
            [sg.Column([[sg.Button("Fechar", button_color=("white", CADEIRA_LIVRE), size=(10,1))]],element_justification="center",pad=(0,10),background_color=BG_CUTE)]
        ]

        window = sg.Window(
            f"Consultório {cons['id']}",
            layout,
            modal=True,
            background_color=PRIMARY,
            finalize=True
        )

        while True:
            event, _ = window.read()
            if event in (sg.WINDOW_CLOSED, "Fechar"):
                break

        window.close()


    #-----------------FORMATAR O POP UP QUE APARECE QUANDO A SIMULAÇÃO TERMINA----------

    def popup_fim_simulacao(resultados):
    
        layout = [
            [sg.Text("✅ Simulação Concluída!", font=("Inter", 15, "bold"), text_color="white", background_color=PRIMARY, justification="center", expand_x=True)],
            [sg.HorizontalSeparator()],
            [sg.Text("Deseja ver os gráficos da simulação?", font=("Inter", 11,"bold"), text_color=PRIMARY,  background_color="white",  justification="center", expand_x=True)],
            [sg.Button("Sim", key="-GRAFICOS-", size=(15, 1), font=("Inter", 11,"bold"), button_color=("white", CADEIRA_LIVRE),pad=(5, 3)),
            sg.Button("Fechar", key="-FECHAR-", size=(15, 1), font=("Inter", 11,"bold"), button_color=("white", CADEIRA_LIVRE), pad=(5, 3))]
        ]

        window = sg.Window(
            "Conclusão da simulação",
            layout,
            modal=True,
            finalize=True,
            background_color=BG
        )

        while True:
            event, _ = window.read()
            if event in (sg.WINDOW_CLOSED, "-FECHAR-"):
                break
            elif event == "-GRAFICOS-":
                gr.mostrar_graficos_finais(resultados)

            
    #--------------------------FORMATAR POP UP QUE APARECE QUANDO CLICAMOS NOS BOTÕES DAS FILAS--------
    def popup_tempo_medio(titulo, tempo_medio):
        BG_CUTE = "#8fd1c9"    
        FRAME_BG = "white"      
        FONT_INFO = ("Inter", 10, "bold")

        layout = [
            [sg.Frame(
                title="",
                layout=[
                    [sg.Text(f"{titulo}: {tempo_medio:.2f} minutos",
                            font=FONT_INFO,
                            text_color=PRIMARY,
                            background_color=FRAME_BG,
                            justification="center")],
                ],
                background_color=FRAME_BG,
                pad=(10,10)
            )],
            [sg.Column(
                [[sg.Button("Fechar", button_color=("white", "#498f89"), size=(10,1))]],
                element_justification="center",
                pad=(0,10),
                background_color=BG_CUTE
            )]
        ]

        window = sg.Window(
            titulo,
            layout,
            modal=True,
            background_color=BG_CUTE,
            finalize=True
        )

        while True:
            event, _ = window.read()
            if event in (sg.WINDOW_CLOSED, "Fechar"):
                break

        window.close()

    
    def run_simulacao(layout, cadeiras):
        #----------------------
        #SIMULAÇÃO
        #----------------------

        simulador = App2.simulação(config_atual)
        

        # ==================================================
        # EVENT LOOP
        # ==================================================

        simulacao_pausada = False #linha necessária para dar run e pause na simulação
        resultados_finais = None
        
        window = sg.Window("Clínica Saúde", layout, resizable=False, finalize=True, background_color="white")
        
        while True:
            event, values = window.read(timeout=200)
            
            if event == "FILA TRIAGEM":
                sg.popup(
                    f"Tamanho da fila: {n_espera}\n"
                    f"Prioritários: {len(fila_triagem[0])}\n"
                    f"Não prioritários: {len(fila_triagem[1])}"
                )
                
            if event == "-PAUSA-":
                simulacao_pausada = not simulacao_pausada

                window["-PAUSA-"].update(
                    "▶ Continuar a simulação" if simulacao_pausada else "⏸ Pausar a simulação"
                )
                
            if event == sg.WINDOW_CLOSED:
                break

            # ----------------------------
            # AVANÇAR SIMULAÇÃO
            # ----------------------------
            if not simulacao_pausada:
                try:
                    t_atual, fila_triagem, filas_consultas, balcoes, medicos, seccoes, doentes_atendidos= next(simulador)
                except StopIteration as e:
                    resultados_finais = e.value
                    popup_fim_simulacao(resultados_finais)
                    break



            # ----------------------------
            # ATUALIZAR CONTADOR DE TEMPO  
            # ----------------------------
            window["-TEMPO-"].update(f"⏱ Relógio: {formatar_tempo(t_atual)}")
            
            
            
            # ----------------------------
            # ATUALIZAR BALCÕES (CORES)
            
            for key, idx in MAPA_BALCOES.items():
                balc = balcoes[idx]
                cor = LIVRE if balc["disponivel"] else OCUPADO
                window[key].update(button_color=("white", cor))
                

            # ----------------------------
            # ATUALIZAR SALA DE ESPERA

            n_espera = len(fila_triagem[0]) + len(fila_triagem[1])

            for i, cadeira in enumerate(CADEIRAS):
                if i < n_espera:
                    cadeira.update(background_color=OCUPADO)
                else:
                    cadeira.update(background_color=CADEIRA_LIVRE)

            # ----------------------------
            # CLIQUE NUM BALCÃO
            
            if event in MAPA_BALCOES:
                balc = balcoes[MAPA_BALCOES[event]]

                info = (
                    f"Balcão {balc['id']}\n\n"
                    f"Prioritário: {'Sim' if balc['prioritario'] else 'Não'}\n"
                    f"Estado: {'Livre' if balc['disponivel'] else 'Ocupado'}\n"
                    f"Doentes atendidos: {balc['ndoentes_atendidos']}\n"
                    f"Tempo total ocupado: {balc['tempo_ocupado']:.1f} min" #.1f uma casa decimal
                )

                sg.popup(info, title="Informação do Balcão")

            # ----------------------------
            # CLIQUE NA SALA DE ESPERA
            
            if event == "-SALA-":
                info = (
                    f"Pessoas em espera: {n_espera}\n"
                    f"Prioritários: {len(fila_triagem[0])}\n"
                    f"Não prioritários: {len(fila_triagem[1])}"
                )

                sg.popup(info, title="Sala de Espera")
                
                
            #------------ CONSULTÓRIOS-----------------------
            MAPA_CONSULTORIOS = consultorios_por_especialidade(seccoes)

            for sec_id, lista_consultorios in MAPA_CONSULTORIOS.items():
                lista = lista_consultorios

                if not lista:
                    cor = LIVRE
                else:
                    todos_em_consulta = all(
                        em_consulta(cons["medico"],t_atual)
                        for cons in lista
                    )
                    cor = OCUPADO if todos_em_consulta else LIVRE

                key = f"-CONS-{sec_id}-"
                if key in window.AllKeysDict:
                    window[key].update(button_color=("white", cor))
                    
                    
            #-------------------------
            #CLIQUE NO CONSULTÓRIO
            
            if event.startswith("-CONS-"): #se começar com -CONS- visto que é assim que é assim a key dos consultórios
                sec_id = event[6:-1] 
                mapa = consultorios_por_especialidade(seccoes)
                consultorios = mapa.get(sec_id, [])

                if not consultorios:
                    sg.popup("Sem consultórios disponíveis")
                    continue

                #escolher consultório
                cons_id = popup_escolher_consultorio(consultorios,t_atual)

                if cons_id is None:
                    continue  #utilizador fechou o popup

                cons = next(c for c in consultorios if c["id"] == cons_id)
                #mostrar informação
                med = cons["medico"]

                if not medico_em_turno(med, t_atual):
                    estado = "Fora de turno"
                elif em_consulta(med, t_atual):
                    estado = "Ocupado"
                else:
                    estado = "Livre"

                doente = med.get("doente")
                nome_doente = doente["nome"] if doente else "—"
                inicio = med.get("inicio_consulta")
                tempo = t_atual - inicio if inicio is not None else 0

                info = (
                    f"Médico: {med['nome']}\n"
                    f"Especialidade: {med['especialidade']}\n"
                    f"Consultório: {cons['id']}\n"
                    f"Doente: {nome_doente}\n"
                    f"Tempo de consulta: {round(tempo,2)} min\n\n"
                    f"Estado: {estado}\n"
                    f"Doentes atendidos: {med['ndoentes_atendidos']}\n"
                    f"Tempo total ocupado: {med['tempo_ocupado']} min"
                )

                popup_info_consultorio(med, cons, t_atual)

            #---------------------
            # CLIQUE NO BOTÃO DE TEMPO MÉDIO NA FILA DA TRIAGEM
                
            if event == "-TWAIT-":
                simulacao_pausada = True

                tempo_medio = Triagem.tempo_medio_FilaTriagem(doentes_atendidos)

                popup_tempo_medio("Tempo médio fila triagem", tempo_medio)

                simulacao_pausada = False
                
            #---------------------
            # CLIQUE NO BOTÃO DE TEMPO MÉDIO NA FILA DE CONSULTA
            
            if event == "-CWAIT-":
                simulacao_pausada = True

                tempo_medio = con.tempo_medio_FilasConsultas(doentes_atendidos)

                popup_tempo_medio("Tempo médio fila consulta", tempo_medio)

                simulacao_pausada = False
                
            #---------------------
            # CLIQUE NO BOTÃO DE EXECUTAR ATÉ AO FIM
            
            if event == "-FAST-":
                simulacao_pausada = True
                try:
                    while True:
                        t_atual, fila_triagem, filas_consultas, balcoes, medicos, seccoes, doentes_atendidos = next(simulador)
                except StopIteration as e:
                    resultados_finais = e.value
                    popup_fim_simulacao(resultados_finais)
                    break 
        window.close()


    run_simulacao(layout, cadeiras)
    return layout,cadeiras

#simulacao_principal()



