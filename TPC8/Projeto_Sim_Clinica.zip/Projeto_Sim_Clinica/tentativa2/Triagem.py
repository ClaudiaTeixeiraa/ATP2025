import json
import random
import numpy as np

#-------------- FICHEIRO QUE PROCESSA OS DOENTES NA RECEÇÃO

#----------------------------------------- FUNÇÕES "AUXILIARES" ------------------------------------------

def prioridadeIndividual(pessoa):
    prior = False
    if pessoa["incapacidade"] == True or pessoa["bebe_ao_colo"] == True or pessoa["gravidez"] == True or pessoa["idade"] <= 2 or pessoa["idade"] >= 75:
        prior = True
    return prior

def temConsulta(): #para perceber se o doente tem consulta ou não (consideramos que 80% das pessoas tem consulta)
    consulta = False
    n = random.randint(1,100) #dizer ao lucas para mudar o dele porque ele tem 101
    if n <= 80:
        consulta = True
    return consulta 

def enqueue(doente, queue):
    queue.append(doente)
    return queue

def unqueue(queue):
    return queue[0], queue[1:]


def doenca():
    n = random.randint(1,101)
    if n <= 7:                      #7% 1 médico
        doenca = "Dermatologia"

    elif n > 7 and n<= 13:                   #+6% = 13% 1 médico
        doenca = "Gastroenterologia"

    elif n> 13 and n <= 18:                   #+5% = 18% 1 médico
        doenca = "Pneumonologia"

    elif n> 18 and n <= 26:                   #+8% = 26% 2 médico
        doenca = "Cardiologia"

    elif n>26 and n <= 29:                   #+3% = 29% 1 médico
        doenca = "Endocrinologia"

    elif n>29 and n <= 38:                   #+9% = 38% 2 médicos
        doenca = "Ortopedia"

    elif n>38 and n <= 44:                   #+6% = 44% 1 médico
        doenca = "Neurologia"

    elif n>44 and n <= 54:                   #+10% = 54% 2 médicos
        doenca = "Ginecologia e Obstetrícia"

    elif n>54 and n <= 58:                   #+4% = 58% 1 médico
        doenca = "Psiquiatria"

    elif n>58 and n <= 70:                   #+12% = 70% 2 médicos
        doenca = "Pediatria"

    else:                           #+30% = 100% 3 médicos
        doenca = "Medicina Geral"

    return doenca


def tempoTriagem(t_atual):
    t_Triagem = max(0.5,np.random.normal(loc=3.0, scale=1.0))  # distribuição normal para tempo na triagem que em média demora 3 minutos e desvio padrão de 1 minuto
    entrada_triagem = t_atual
    saida_triagem = t_atual + t_Triagem
    t_atual += t_Triagem
    return entrada_triagem, saida_triagem, t_Triagem

#---------------------------------------------------------------------------------------


def Doentes(ficheiro):
    doentes = []
    f = open(ficheiro, "r", encoding = "utf-8")
    lista = json.load(f)
    for pessoa in lista:
        doente = {
        "nome": pessoa["nome"],
        "idade": pessoa["idade"],
        "sexo": pessoa["sexo"],
        "id": pessoa["id"],
        "BI": pessoa["BI"],
        "consulta": temConsulta(),
        "especialidade": doenca(),
        "prioridade": prioridadeIndividual(pessoa),
        "tchegada": None, #Chegada ao posto médico
        "tentrada_triagem":None, #Entrada na triagem
        "tsaida_triagem": None, #saída da triagem
        "tentrada_consultorio" : None, #entrada no consultório,
        "tsaida_consultorio":None, #saida do consultorio
        "aguarda_consultorio" :False,
        "estado_final" : None  ##(FILA_TRIAGEM, TRIAGEM, FILA_CONSULTORIO, CONSULTA, ATENDIDO)
        }
        doentes.append(doente)
    f.close()
    return doentes

#---------------------CÁLCULOS DOS TEMPOS--------------
#tempo de espera na fila para a triagem: tentrada_triagem - tchegada
#tempo na triagem: distribuição normal -> tsaída_triagem-tentrada_triagem
#tempo de espera na fila para a consultorio: tentrada_consultorio- tsaida_triagem
#tempo de consulta: distribuição normal ->  tsaida_consultorio-tentrada_consultorio

#TEMPO TOTAL: tsaida_consultorio-tchegada

#------------------- atender os pacientes que chegam -----------------------


def chegadaAntesTriagem(doente, fila_triagem):  #---------Fila antes de ser atendido na receção, ou seja, à chegada à clínica---------
    # doente prioritário fica atrás do último prioritário da fila
    prioritarios=fila_triagem[0]
    resto= fila_triagem[1] #o resto são os pacientes que não são prioritários
    if doente["prioridade"] == True:
        prioritarios.append(doente)
            
    elif doente["consulta"] == True :
        j = 0                                                                            
        while j < len(resto) and resto[j]["consulta"]:
            j += 1
            
        resto.insert(j, doente)

    else:
        resto.append(doente)  # quem não tem, vai para o fim da lista de espera inteira
    
    return fila_triagem


#------------------Atendiemneto ao balcão----------------------------------------


balcoes = [
    {"id":1, "prioritario":True,  "disponivel":True, "doente":None, "entrada":None, "saida":None, "ndoentes_atendidos" : 0, "tempo_ocupado": 0.0},
    {"id":2, "prioritario":False, "disponivel":True, "doente":None, "entrada":None, "saida":None, "ndoentes_atendidos" : 0, "tempo_ocupado": 0.0},
    {"id":3, "prioritario":False, "disponivel":True, "doente":None, "entrada":None, "saida":None, "ndoentes_atendidos" : 0, "tempo_ocupado": 0.0}
]

#-------------criar balcoes------------------

def criaBalcoes(config_atual):

    nbalcoes=config_atual["nbalcoes"]
    nbalcoes_prior = config_atual["nbalcoes_prior"]

    balcoes = []

    for i in range(1, nbalcoes + 1):
        balcoes.append({
            "id": i,
            "prioritario": False,
            "disponivel": True,
            "doente": None,
            "entrada": None,
            "saida": None,
            "ndoentes_atendidos": 0,
            "tempo_ocupado": 0.0
        })
    
    # Marca os primeiros nbalcoes_prior como prioritários
    for i in range(0,nbalcoes_prior):
        balcoes[i]["prioritario"] = True

    return balcoes



def ocupar_balcaoTriagem(lista,balcoes,t_atual):
    fila_prioritario = lista[0]
    fila_resto=lista[1]
    evento = None
    eventos_gerados=[]
    for balcao in balcoes:
        if balcao["prioritario"] and balcao["disponivel"] and fila_prioritario:  #and fila_prioritario verifica que a lista não é uma lista vazia
            doente = fila_prioritario.pop(0)  
            entrada = max(t_atual, doente["tchegada"])  #o max define o tempo de início da triagem como o maior entre t_atual e tchegada: se o balcão estiver livre antes da chegada do doente, usa tchegada; se estiver livre depois da chegada, usa t_atual

            _, saida, t_Triagem = tempoTriagem(entrada)

            
            balcao.update({
                "doente": doente,
                "disponivel": False,
                "entrada": entrada,
                "saida": saida,
                "ndoentes_atendidos" : balcao["ndoentes_atendidos"] + 1,
                "tempo_ocupado": balcao["tempo_ocupado"] + t_Triagem
            })

            doente.update({
                "tentrada_triagem" : entrada,
                "tsaida_triagem": round(saida,2),
                "estado_final": "TRIAGEM" #registo
            })
            
            evento = {
                "tempo" : doente["tsaida_triagem"],
                "tipo" : "SAI_TRIAGEM",
                "doente" : doente,
                "balcao" : balcao["id"]
            }
            eventos_gerados.append(evento)

        elif not balcao["prioritario"] and balcao["disponivel"] and fila_resto:
            doente = fila_resto.pop(0) 
            entrada = max(t_atual, doente["tchegada"])
            _, saida, t_Triagem = tempoTriagem(entrada)

            
            balcao.update({
                "doente": doente,
                "disponivel": False,
                "entrada": entrada,
                "saida": saida,
                "ndoentes_atendidos" : balcao["ndoentes_atendidos"] + 1,
                "tempo_ocupado": balcao["tempo_ocupado"] + t_Triagem
            })

            doente.update({
                "tentrada_triagem" : entrada,
                "tsaida_triagem": round(saida,2),
                "estado_final" : "TRIAGEM" #registo
            })

            evento = {
                "tempo" : doente["tsaida_triagem"],
                "tipo" :"SAI_TRIAGEM",
                "doente" : doente,
                "balcao" : balcao["id"]
            }
            eventos_gerados.append(evento)

    return lista, balcoes, eventos_gerados

#----------------------------Desocupar o balcão---------------------------------

def desocupar_balcaoTriagem(balcoes, t_atual):
    eventos_gerados = []
    evento = None
    for balcao in balcoes:
        if not balcao["disponivel"] and t_atual >= balcao["saida"]:

            doente = balcao["doente"]
        

            balcao.update({
                    "doente": None,
                    "disponivel": True,
                    "entrada": None,
                    "saida": None
                })
            
            doente["estado_final"] = "FILA_CONSULTORIO" #registo

            eventos_gerados.append(evento)
    return balcoes, eventos_gerados


def tempo_medio_FilaTriagem(doentes_atendidos):
    diferenca = []
    for doente in doentes_atendidos:
        if doente["tentrada_triagem"] != None:
            diferenca.append((doente["tentrada_triagem"] - doente["tchegada"]))

    media = round(sum(diferenca)/len(diferenca),2)

    return media

