import Simulacao as App2 

#--------FICHEIRO PARA DAR RUN À SIMULAÇÃO ATÉ AO FIM-------

#É neste ficheiro que conseguimos dar run à simulação do inicio ao fim. No Simulacao.py a simulação é um gerador útil para as interfaces pelo que conseguimos aceder à simulação antes mesmo dela acabar

def executar_simulacao(config_atual):
    simulador = App2.simulação(config_atual)

    try:
        while True:
            next(simulador)
    except StopIteration as e:
        resultados = e.value   #dicionário final
    
    #agora isto funciona
    doentes_atendidos = resultados["doentes_atendidos"]

    FILA_TRIAGEM = TRIAGEM = FILA_CONSULTORIO = CONSULTA = ATENDIDO = 0

    for doente in doentes_atendidos:
        if doente["estado_final"] == "FILA_TRIAGEM":
            FILA_TRIAGEM += 1
        elif doente["estado_final"] == "TRIAGEM":
            TRIAGEM += 1
        elif doente["estado_final"] == "FILA_CONSULTORIO":
            FILA_CONSULTORIO += 1
        elif doente["estado_final"] == "CONSULTA":
            CONSULTA += 1
        elif doente["estado_final"] == "ATENDIDO":
            ATENDIDO += 1

    
    tam_filas_consultas_total = resultados["tam_filas_consultas_total"]
    tempos = resultados["tempos"]
    tam_fila_triagem = resultados["tam_fila_triagem"]
    tam_filas_consultas = resultados["tam_filas_consultas"]
    ocupacao_medicos = resultados["ocupacao_medicos"]
    fila_triagem = resultados["fila_triagem"]
    filas_consultas = resultados["filas_consultas"]
    medicos = resultados["medicos"]
    doentes_atendidos= resultados["doentes_atendidos"]
    taxas = resultados["taxas"]

    #print(filas_consultas)
    print(medicos)
    #print(doentes_atendidos)
    print(taxas)
    print(f"Fila Triagem: {FILA_TRIAGEM} , Na triagem: {TRIAGEM} , Fila Consultório: {FILA_CONSULTORIO} , Em consulta: {CONSULTA}, Atendidos: {ATENDIDO}")

    return resultados


