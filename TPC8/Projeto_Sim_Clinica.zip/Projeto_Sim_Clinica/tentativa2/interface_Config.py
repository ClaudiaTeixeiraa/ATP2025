import FreeSimpleGUI as sg
import config_model as CM

#------ FICHEIRO PARA INTERFACE DAS CONFIGURAÇÕES-------

config_atual = CM.config_default()

def interface_Config(config_atual,modos_taxas):

    PRIMARY = "#429c91"
    BG = "#f2f2f2"

    MODOS = ["Calmíssimo","Calmo", "Default", "Cheio", "Cheiíssimo"]

    
    config_layout= [

        [sg.Text("CONFIGURAÇÕES- CLÍNICA SAÚDE", text_color="white", font=("Inter",18,"bold"), justification = "center",background_color="#234C4C")],

        [sg.HorizontalSeparator()],

        [sg.Text("NÚMERO TOTAL DE BALCÕES DE ATENDIMENTO:",background_color="#234C4C"), sg.Spin(list(range(2,11)), initial_value = config_atual["nbalcoes"], key="-BTOTAL-", size = (20,1), readonly=True, background_color="#234C4C")],  #sg.Spin-- Input seta para cima, seta para baixo

        [sg.Text("NÚMERO DE BALCÓES DE ATENDIMENTO PRIORITÁRIOS:", background_color="#234C4C"),sg.Spin(list(range(1,11)), initial_value= config_atual["nbalcoes_prior"], key= "-BPRIOR-", size = (20,1), readonly=True, background_color="#234C4C")],

        [sg.Text("MODO DE FUNCIONAMENTO DA CLÍNICA:", background_color="#234C4C"), sg.Combo(MODOS, default_value = MODOS[2], key = "-MODO-", readonly = True)], #sg.Combo-- deixa escolher uma opção,  # readonly-- impede digitar manualmente
        
        [sg.Button("✅GUARDAR", key = "-SAVE-", size= (10,1), button_color = ("white", PRIMARY)) ],

        [sg.Button("❌ Cancelar",key = "-CANCEL-", size= (10,1), button_color = ("white", PRIMARY))]
        
        ]



    config_window = sg.Window(
        "CONFIGURAÇÕES",
        config_layout,
        modal = True,
        finalize= True,
        element_justification= "center",
        background_color="#234C4C"
    )

    STOP = False

    while not STOP:
        event,values = config_window.read()

        if event == "-CANCEL-" or event == sg.WINDOW_CLOSED:
            STOP = True

        if event =="-SAVE-":
            nbalcoes = int(values["-BTOTAL-"])
            nbalcoes_prior = int(values["-BPRIOR-"])
            modo = values["-MODO-"]

            STOP = True
            

            if nbalcoes <= nbalcoes_prior:
                sg.popup_error("O número de balcões prioritários não pode ser maior ou igual ao número total de balcões.")
                continue # continue faz com que quando entra uma condição no loop, ignora o restante código e inicia um novo loop

            config_atual["nbalcoes"] = nbalcoes
            config_atual["nbalcoes_prior"] = nbalcoes_prior
            config_atual["modo"] = modo

            if modo not in modos_taxas:
                sg.popup_error(f"Modo inválido selecionado: {modo}")
                continue

            config_atual["taxas"] = modos_taxas[modo]

            sg.popup("Configurações guardadas com sucesso!", title="Sucesso", background_color="#234C4C", text_color="white")




    config_window.close()

    return config_atual
