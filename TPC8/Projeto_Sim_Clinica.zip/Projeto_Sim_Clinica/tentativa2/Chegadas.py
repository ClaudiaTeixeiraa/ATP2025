import numpy as np
import random

#-----FICHEIRO PARA AS CHEGADAS

tfinal = 12*60

#def gera_tempos_chegada(tfinal):

    #taxas = [ 
        #(0, 2 * 60, 12*1.5 / 60),#18
        #(2 * 60, 4 * 60, 5*1.5 / 60),#11
        #(4 * 60, 7 * 60, 3*1.5 / 60),#7
        #(7 * 60, 9 * 60, 4*1.5 / 60),#9
        #(9 * 60, 12 * 60, 10*1.5 / 60)#16
    #]

    #tchegadas = []
    #tempo_atual = 0.0

    #for hinicio, hfim, taxa in taxas:
        #começa no início do bloco ou no tempo atual
        #tempo_atual = max(tempo_atual, hinicio)
        #gera chegadas dentro do bloco
        #while tempo_atual < hfim and tempo_atual < tfinal:
            #intervalo = np.random.exponential(1 / taxa)
            #tempo_atual += intervalo

            #if tempo_atual < hfim and tempo_atual < tfinal:
                #tchegadas.append(round(tempo_atual,2))

    #return tchegadas


def janelas_funcionamentoEspecialidades(medicos):
    horarios = {}

    for medico in medicos:
        esp = medico["especialidade"]
        
        if esp not in horarios:
            horarios[esp] =horarios[esp] = {
                "inicio": medico["inicio_turno"],
                "fim": medico["fim_turno"]
            }
            
        else:
            horarios[esp]["inicio"] = min(horarios[esp]["inicio"], medico["inicio_turno"])
            horarios[esp]["fim"] = max(horarios[esp]["fim"], medico["fim_turno"])
    
    return horarios


def chegada_valida(doente, t_chegada, horarios):
    esp = doente["especialidade"]
    h = horarios[esp]
    return h["inicio"] <= t_chegada <= h["fim"]

