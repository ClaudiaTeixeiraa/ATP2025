import json
import numpy as np

#------ FICHEIRO PARA ASSOCIAR PACIENTES A MÉDICOS

#--------------FUNÇÕES PARA TRATAMENTO DE DADOS----------------------

def carregaMedicos(ficheiro):
    medicos = []
    with open("./tentativa2/medicos.json", "r", encoding="utf-8") as p:
        lista_medicos = json.load(p)
        for pessoa in lista_medicos:
            medico = {
                "nome": pessoa["nome"],
                "id": pessoa["id"],
                "disponibilidade": True,
                "doente": None,
                "inicio_consulta":None,
                "fim_consulta":None,
                "inicio_turno":pessoa["inicio_turno"],
                "fim_turno":pessoa["fim_turno"],
                "especialidade": pessoa["especialidade"],
                "ndoentes_atendidos": 0,
                "id_doentes_atendidos" : [],
                "tempo_ocupado":0
                }
            medicos.append(medico)
    return medicos

seccoes = [{"especialidade": "Dermatologia", "id": "s1", "consultorios":[]},

            {"especialidade": "Gastroenterologia", "id": "s2", "consultorios":[]},
                                                                            
            {"especialidade": "Pneumonologia", "id": "s3", "consultorios":[]},
            
            {"especialidade": "Cardiologia", "id": "s4", "consultorios":[]},
            
            {"especialidade": "Endocrinologia", "id": "s5","consultorios":[]},
                                                                        
            {"especialidade": "Ortopedia", "id": "s6","consultorios":[]},
            
            {"especialidade": "Neurologia", "id": "s7","consultorios":[]},

            {"especialidade": "Ginecologia e Obstetrícia", "id": "s8","consultorios":[]},

            {"especialidade": "Psiquiatria", "id": "s9","consultorios":[]},

            {"especialidade": "Pediatria", "id": "s10","consultorios":[]},

            {"especialidade": "Medicina Geral", "id": "s11","consultorios":[]}]


def cria_id(medico):
    c = medico["id"]
    num = c[1:]
    return num

def criaConsultorios(medicos,seccoes):
    for medico in medicos:
        n = 0
        while n < len(seccoes): 
            if medico["especialidade"] == seccoes[n]["especialidade"]:
                seccoes[n]["consultorios"].append({"id":"c" + cria_id(medico), "medico":medico})
                n +=1
            else: 
                n +=1
    return seccoes
    
#----------------FUNÇÕES COM PAPEL DIRETO NA SIMULAÇÃO-----------------

def encontraDoente(doente,fila):
    if doente != None:
        v = 0
        pronto = False
        while v < len(fila) and not pronto:
            if fila[v]["id"] == doente["id"] and doente["tentrada_consultorio"] != None:
                fila.pop(v)
                pronto = True
            else:
                v +=1
    return fila

tempo_consulta_especialidade = [
    {"especialidade": "Cardiologia", "tempo_medio_consulta": 30},
    {"especialidade": "Pediatria", "tempo_medio_consulta": 20},
    {"especialidade": "Dermatologia", "tempo_medio_consulta": 15},
    {"especialidade": "Gastroenterologia", "tempo_medio_consulta": 25},
    {"especialidade": "Pneumonologia", "tempo_medio_consulta": 25},
    {"especialidade": "Endocrinologia", "tempo_medio_consulta": 20},
    {"especialidade": "Ortopedia", "tempo_medio_consulta": 20},
    {"especialidade": "Neurologia", "tempo_medio_consulta": 30},
    {"especialidade": "Ginecologia e Obstetrícia", "tempo_medio_consulta": 25},
    {"especialidade": "Psiquiatria", "tempo_medio_consulta": 45},
    {"especialidade": "Medicina Geral", "tempo_medio_consulta": 15}
]


def atribuir_doente_a_medico(doente, seccoes, t_atual):
    medicos_seccao = None
    i = 0

    while i < len(seccoes) and medicos_seccao is None:
        sec = seccoes[i]
        if sec["especialidade"] == doente["especialidade"]:
            medicos_seccao = [c["medico"] for c in sec["consultorios"]]
        i += 1

    for m in medicos_seccao:
        m["disponibilidade"] = (m["inicio_turno"] <= t_atual < m["fim_turno"]and m["doente"] is None)
        
    disponiveis = [m for m in medicos_seccao if m["inicio_turno"] <= t_atual < m["fim_turno"] and m["doente"] is None]

    if not disponiveis:
        return None

    medico = min(disponiveis, key=lambda m: m["ndoentes_atendidos"])

    tempo = None
    i = 0

    while i < len(tempo_consulta_especialidade) and tempo is None:
        t = tempo_consulta_especialidade[i]
        if t["especialidade"] == medico["especialidade"]:
            tempo = max(5, np.random.normal(t["tempo_medio_consulta"], 5))
        i += 1
        
    medico["doente"] = doente
    medico["disponibilidade"] = False
    medico["inicio_consulta"] = round(t_atual, 2)
    medico["fim_consulta"] = round(t_atual + tempo, 2)
    doente["tentrada_consultorio"] = medico["inicio_consulta"]
    doente["tsaida_consultorio"] = medico["fim_consulta"]
    medico["ndoentes_atendidos"] += 1
    medico["id_doentes_atendidos"].append(doente["id"])
    medico["tempo_ocupado"] = round(medico["tempo_ocupado"] + tempo,2)
    doente["estado_final"] = "CONSULTA" #registo

    return medico #encontrou um médico


def desocuparMedico(medico,t_atual):
    if medico != None:
        if medico["fim_consulta"] != None:
            if t_atual >= medico["fim_consulta"] :

                doente = medico["doente"]
                doente["estado_final"] = "ATENDIDO" #registo

                medico.update({
                "disponibilidade": True,
                "doente": None,
                "inicio_consulta":None,
                "fim_consulta":None,
                })

    return medico

def tentar_atribuir_fila(esp, filas_consultas, seccoes, eventos, t_atual):
    continuar = True

    while continuar == True:
        if filas_consultas[esp]["com_consulta"]:
            doente = filas_consultas[esp]["com_consulta"][0]
            origem = "com_consulta"

        elif filas_consultas[esp]["sem_consulta"]:
            doente = filas_consultas[esp]["sem_consulta"][0]
            origem = "sem_consulta"

        else:
            continuar = False

        if continuar == True:
            medico = atribuir_doente_a_medico(doente, seccoes, t_atual)

            if medico:
                filas_consultas[esp][origem].pop(0)

                eventos.append({
                    "tempo": medico["fim_consulta"],
                    "tipo": "SAI_CONSULTORIO",
                    "doente": doente,
                    "medico": medico
                })

                eventos.sort(key=lambda e: e["tempo"])
            else:
                continuar = False
        


#-------------------FUNÇÕES PARA GERAÇÃO DE ESTATÍSTICAS-------------------------------

def tamanho_filas_cosultas(filas_consultas,tam_filas):

    for esp, fila in filas_consultas.items():

        if esp not in tam_filas:
            tam_filas[esp] = {
                "sem_consulta" : [],
                "com_consulta" : [],
                "tam_total" : []
            }
            tam_filas[esp]["sem_consulta"] = [len(fila["sem_consulta"])]
            tam_filas[esp]["com_consulta"] = [len(fila["com_consulta"])]
            tam_filas[esp]["tam_total"] = [len(fila["sem_consulta"]) + len(fila["com_consulta"])]
        
        else:
            tam_filas[esp]["sem_consulta"]= tam_filas[esp]["sem_consulta"] + [len(fila["sem_consulta"])]
            tam_filas[esp]["com_consulta"] = tam_filas[esp]["com_consulta"] + [len(fila["com_consulta"])]
            tam_filas[esp]["tam_total"] = tam_filas[esp]["tam_total"] + [len(fila["sem_consulta"]) + len(fila["com_consulta"])]

    return tam_filas


def tamanho_total_filasconsultas(filas_consultas,tam_filas,tam_filas_total):
    soma = 0
    
    for esp,tams in tam_filas.items():
        soma += tam_filas[esp]["tam_total"][-1]

    tam_filas_total.append(soma)
        
    return tam_filas_total


def media_tamanho_filas_consultas(tam_filas):

    med_filas = {}

    def calcula_media(fila):
        media = None
        if len(fila) != 0:
            media = sum(fila)/len(fila)
        return media

    for esp, fila in tam_filas.items():

        med_filas[esp] = {
            "media_sem_consulta": calcula_media(fila.get("sem_consulta", [])),
            "media_com_consulta": calcula_media(fila.get("com_consulta", [])),}
        if med_filas[esp]["media_com_consulta"] == None and med_filas[esp]["media_sem_consulta"] == None:
            med_filas[esp]["media_da_especialidade"] = None
        elif med_filas[esp]["media_com_consulta"] == None:
            med_filas[esp]["media_da_especialidade"] = med_filas[esp]["media_sem_consulta"]
        elif med_filas[esp]["media_sem_consulta"] == None:
            med_filas[esp]["media_da_especialidade"] = med_filas[esp]["media_com_consulta"]
        else:
            med_filas[esp]["media_da_especialidade"] = (med_filas[esp]["media_sem_consulta"] + med_filas[esp]["media_com_consulta"])/2

    return med_filas


def med_filas_consultas(med_filas):
    
    lista_soma = []

    for _,media in med_filas.items():

        if media["media_da_especialidade"] != None:
            lista_soma.append(media["media_da_especialidade"])
    
    media_final = None

    if lista_soma != []:
        media_final = sum(lista_soma)/len(lista_soma)
    
    return media_final
    
    
    
def tempo_medio_FilasConsultas(doentes_atendidos):

    diferenca = []
    for doente in doentes_atendidos:
        if doente["tentrada_consultorio"] != None:
            diferenca.append((doente["tentrada_consultorio"] - doente["tsaida_triagem"]))

    media = round( sum(diferenca)/len(diferenca),2)

    return media