import Interface_Menu as IM
import FreeSimpleGUI as sg

#FICHEIRO DE EXTREMA RELEVÂNCIA!!!

#------ FICHEIRO PARA DAR RUN À INTERFACE INTEIRA------

PRIMARY = "#429c91"
HEADER_BG = "#6f7f8f"
BG = "#f2f2f2"
OCUPADO = "#d15050"
LIVRE = PRIMARY
CADEIRA_LIVRE = "#9aa3ad"
CADEIRA_OCUPADA = "red"

ALUMINIO = "#6e747a"   #estrutura 
VIDRO = "#e6f2fa"      #vidro

FONT_TITLE = ("Inter", 18, "bold")
FONT_BUTTON = ("Inter", 10)


modos_taxas={
        "Calmíssimo":[  
        (0, 2 * 60, 20*0.5/ 60),
        (2 * 60, 4 * 60, 14*0.5/ 60),
        (4 * 60, 7 * 60, 9*0.5/ 60),
        (7 * 60, 9 * 60, 11*0.5/ 60),
        (9 * 60, 12 * 60, 19*0.5/ 60)],
        "Calmo":[  
        (0, 2 * 60, 20/ 60),
        (2 * 60, 4 * 60, 14 / 60),
        (4 * 60, 7 * 60, 9/ 60),
        (7 * 60, 9 * 60, 11/ 60),
        (9 * 60, 12 * 60, 19/ 60)],
        "Default":[  
        (0, 2 * 60, 20*2/ 60),
        (2 * 60, 4 * 60, 14*2 / 60),
        (4 * 60, 7 * 60, 9*2/ 60),
        (7 * 60, 9 * 60, 11*2/ 60),
        (9 * 60, 12 * 60, 19*2 / 60)],
        "Cheio":[ 
        (0, 2 * 60, 20*5/ 60),
        (2 * 60, 4 * 60, 14*5 / 60),
        (4 * 60, 7 * 60, 9*5/ 60),
        (7 * 60, 9 * 60, 11 *5/ 60),
        (9 * 60, 12 * 60, 19*5 / 60)],
        "Cheiíssimo" :[ 
        (0, 2 * 60, 20*10/ 60),
        (2 * 60, 4 * 60, 14*10 / 60),
        (4 * 60, 7 * 60, 9*10/ 60),
        (7 * 60, 9 * 60, 11 *10/ 60),
        (9 * 60, 12 * 60, 19*10 / 60)]
    }

config_atual = {"taxas":modos_taxas["Default"],
            "nbalcoes":5,
            "nbalcoes_prior":2,
            "modo":"Default"}

IM.interface_Menu()