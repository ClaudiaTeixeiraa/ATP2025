import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import Consultorios as con

#--------FICHEIRO PARA GERAÇÃO SE GRÁFICOS-------
    
def alinhar_series(*series):
    n = min(len(s) for s in series)
    return [s[:n] for s in series]


#Tempo médio de espera por doente
def tempo_medio_espera_doente(tempos, tam_fila_triagem):
    plt.figure(figsize=(12, 10))
    plt.plot(tempos, tam_fila_triagem, color="#429c91", marker=".", linewidth=1)
    plt.xlabel("Tempo da simulação (min)")
    plt.ylabel("Tamanho da fila de triagem (nº de pessoas)")
    plt.title("Evolução do tamanho da fila de espera")

    plt.xlim(0, 720)
    #escala do eixo Y: de 1 em 1
    max_y = max(tam_fila_triagem) if tam_fila_triagem else 0
    plt.yticks(range(0, max_y +2 , len(tam_fila_triagem)//(len(tam_fila_triagem)//5)))

    #escala do eixo X: de 120 em 120
    plt.xticks(range(0,721,120))
    plt.grid(plt.grid(
        which="major",
        linestyle="--",
        linewidth=0.6,
        alpha=0.5
    ))

    #remover bordas desnecessárias
    plt.gca().spines["top"].set_visible(False)
    plt.gca().spines["right"].set_visible(False)
    plt.tight_layout()
    plt.show()
    return 

#tempo_medio_espera_doente(tempos,tam_fila_triagem)

#Numero de doentes ocupados por  medico
def doentes_atendidos_por_medico(medicos):
    nomes = [m["nome"] for m in medicos]
    atendidos = [m["ndoentes_atendidos"] for m in medicos]
    especialidades = [m["especialidade"] for m in medicos]


    cores_especialidades = {"Cardiologia": "#D57A8C",               
                            "Pediatria": "#BEE7E8",                  
                            "Dermatologia": "#FEA8FF",              
                            "Gastroenterologia": "#E7E1B5",      
                            "Pneumonologia": "#A8D5BA",            
                            "Endocrinologia": "#8D81A7",             
                            "Ortopedia": "#F7C59F",                  
                            "Neurologia": "#CDB4DB",                   
                            "Ginecologia e Obstetrícia": "#BA729C",    
                            "Psiquiatria": "#CBB2FC",                  
                            "Medicina Geral": "#A2DA98"                
                            }


    cores = [cores_especialidades[esp] for esp in especialidades]

    plt.figure(figsize=(12, 6))
    barras=plt.bar(nomes, atendidos, color=cores)
    labels = [f"{atend:.2f}" for atend in atendidos]
    plt.bar_label(barras,padding=3)
    plt.xticks(rotation=60)
    plt.ylabel("Número de doentes (nº de pessoas)")
    plt.title("Número de doentes atendidos por médico (nº de pessoas)")

    # legenda
    legendas = [
        mpatches.Patch(color=cor, label=esp)
        for esp, cor in cores_especialidades.items()
    ]
    plt.legend(
        handles=legendas,
        title="Especialidade",
        bbox_to_anchor=(1.02, 1),
        loc="upper left"
    )

    plt.grid(True,which="major", color="#b5b4b4",alpha=0.5,linewidth=0.7,linestyle="--")
    plt.tight_layout()
    plt.show()

#doentes_atendidos_por_medico(medicos)


#Tempo total ocupado por médico
def tempo_total_ocupado_medicos(medicos):
    ocupacao = [m["tempo_ocupado"] for m in medicos]
    nomes = [m["nome"] for m in medicos]
    especialidades = [m["especialidade"] for m in medicos]


    cores_especialidades = {"Cardiologia": "#D57A8C",               
                            "Pediatria": "#BEE7E8",                  
                            "Dermatologia": "#FEA8FF",              
                            "Gastroenterologia": "#E7E1B5",      
                            "Pneumonologia": "#A8D5BA",            
                            "Endocrinologia": "#8D81A7",             
                            "Ortopedia": "#F7C59F",                  
                            "Neurologia": "#CDB4DB",                   
                            "Ginecologia e Obstetrícia": "#BA729C",    
                            "Psiquiatria": "#CBB2FC",                  
                            "Medicina Geral": "#A2DA98"                
                            }


    cores = [cores_especialidades[esp] for esp in especialidades]
    plt.figure(figsize=(14, 7))
    barras=plt.bar(nomes, ocupacao, color = cores)
    labels = [f"{ocup:.2f}" for ocup in ocupacao]
    plt.bar_label(barras,labels=labels,padding=3)
    plt.xticks(rotation=60)
    plt.ylabel("Tempo ocupado (min)")
    plt.title("Tempo total ocupado por médico (min)")
    
    legendas = [
        mpatches.Patch(color=cor, label=esp)
        for esp, cor in cores_especialidades.items()
    ]
    plt.legend(
        handles=legendas,
        title="Especialidade",
        bbox_to_anchor=(1.02, 1),
        loc="upper left"
    )
    
    plt.grid(True,which="major", color="#b5b4b4",alpha=0.5,linewidth=0.7,linestyle="--")
    plt.tight_layout()
    plt.show()
    return 
#tempo_total_ocupado_medicos(medicos)

#define o número de estados total
def conta_estado_final(doentes_atendidos):
    FILA_TRIAGEM = 0
    TRIAGEM = 0
    FILA_CONSULTORIO = 0
    CONSULTA = 0
    ATENDIDO = 0

    for doente in doentes_atendidos:
        
        if doente["estado_final"] == "FILA_TRIAGEM":
            FILA_TRIAGEM +=1
        elif doente["estado_final"] == "TRIAGEM":
            TRIAGEM +=1
        elif doente["estado_final"] == "FILA_CONSULTORIO":
            FILA_CONSULTORIO +=1
        elif doente["estado_final"] == "CONSULTA":
            CONSULTA +=1
        elif doente["estado_final"] == "ATENDIDO":
            ATENDIDO +=1
    
    return FILA_TRIAGEM , TRIAGEM , FILA_CONSULTORIO , CONSULTA, ATENDIDO


#Gráfico do estado final dos doentes quando a simulação termina
def grafico_estado_final(doentes_atendidos):
    
    FILA_TRIAGEM , TRIAGEM , FILA_CONSULTORIO , CONSULTA, ATENDIDO = conta_estado_final(doentes_atendidos)

    labels_ = ["Fila para a triagem" , "Triagem" , "Fila para o consultório" , "Consulta", "Atendido"]
    valores_ = [FILA_TRIAGEM , TRIAGEM , FILA_CONSULTORIO , CONSULTA, ATENDIDO]
    cores_ = ["#f089d1", "#dede65","#429c91","#5fbc6a", "#f09b5e"]

    valores = []
    labels = []
    cores = []

    n = 0
    while n < len(valores_):
        if valores_[n] > 0:
            valores.append(valores_[n])
            cores.append(cores_[n])
            labels.append(labels_[n])
            
        n += 1


    #fuunção auxiliar que permite  a legenda do gráfico
    def mostrar_valor_perc(perc):
        valor = int(round(perc * (sum(valores)))/100)
        return f"{perc:.1f}%({valor})"

    cores = [ "#f089d1", "#dede65", "#429c91","#5fbc6a", "#6e429c"]


    plt.pie(valores, colors = cores, autopct = mostrar_valor_perc, startangle= 0, pctdistance= 1.18, labeldistance= 1.33)   
    plt.legend(labels, title = "Estado", loc = "lower left", bbox_to_anchor = (-0.1,-0.1)) 
    plt.title("Estado final dos doentes registados na clínica", pad = 20)
    plt.text(0,-1.3, f"TOTAL = {sum(valores)} (100%)", ha = "center", fontsize = 10)
    plt.axis("equal")
    plt.show()

    return

#grafico_estado_final(doentes_atendidos)


#----------------Gráfico mostrando a relação do tamanho médio da fila de espera com a taxa de chegada de doentes-------------

#meds_filas_consultas = con.media_tamanho_filas_consultas(tam_filas_consultas)

#med_final_filas_consultas = con.med_filas_consultas(meds_filas_consultas)
# mostra os tamanhos médios das filas de consultas por especialidade
def grafico_media_tams_filasconsultas(tam_filas_consultas):

    meds_filas_consultas = con.media_tamanho_filas_consultas(tam_filas_consultas)

    med_final_filas_consultas = con.med_filas_consultas(meds_filas_consultas)

    especialidades = list(meds_filas_consultas.keys())
    medias = [meds["media_da_especialidade"] or 0 for meds in meds_filas_consultas.values()]

    cores_especialidades = {"Cardiologia": "#D57A8C",               
                            "Pediatria": "#BEE7E8",                  
                            "Dermatologia": "#FEA8FF",              
                            "Gastroenterologia": "#E7E1B5",      
                            "Pneumonologia": "#A8D5BA",            
                            "Endocrinologia": "#8D81A7",             
                            "Ortopedia": "#F7C59F",                  
                            "Neurologia": "#CDB4DB",                   
                            "Ginecologia e Obstetrícia": "#BA729C",    
                            "Psiquiatria": "#CBB2FC",                  
                            "Medicina Geral": "#A2DA98"                
                            }
    
    cores = [cores_especialidades[esp] for esp in especialidades]

    plt.figure(figsize=(12, 6))
    barras=plt.bar(especialidades, medias, color = cores)
    labels = [f"{med:.2f}" for med in medias]
    plt.bar_label(barras,labels=labels, padding=3)
    plt.xticks(rotation=60)
    plt.ylabel("Média do tamanho da fila (nº de pessoas)")
    plt.title("Médias dos tamanhos das filas para os consultórios por especialidade")
    plt.grid(True,which="major", color="#b5b4b4",alpha=0.5,linewidth=0.7,linestyle="--")
    plt.tight_layout()
    plt.show()
    return

##grafico_media_tams_filasconsultas(meds_filas_consultas)

#mostra a evolução do tamanho médio das filas de consultas e triagem em função do tempo
def tam_filas_VS_tempo(tempos,tam_filas_consultas_total, tam_fila_triagem):

    plt.figure(figsize= (14,7))

    plt.plot(tempos, tam_fila_triagem, label="Fila Triagem", color="black",marker="." ,linewidth=1.0)

    plt.plot(tempos, tam_filas_consultas_total, label= "Filas para as Consultas", color = "#429c91",marker=".", linewidth=1.0)
    plt.xlabel("Tempo (min)")
    plt.ylabel("Tamanho da fila (nº de pessoas)")
    plt.xlim(0, 720)
    max_y = max(max(tam_filas_consultas_total),max(tam_fila_triagem)) 
    plt.yticks(range(0, max_y +2 , len(tam_filas_consultas_total)//(len(tam_filas_consultas_total)//5)))
    plt.xticks(range(0,721,60))
    plt.title("Evolução instantânea das filas de espera ao longo do tempo")
    plt.grid(True)
    
    legendas = [mpatches.Patch(color="#429c91", label="Filas para as consultas")] + [mpatches.Patch(color="black", label="Triagem")]
    plt.legend(
        handles=legendas,
        title="Tipo de Fila",
        bbox_to_anchor=(1.05, 1),
        loc="upper left"
    )
    plt.tight_layout()
    plt.show()

#tam_filas_VS_tempo(tempos,tam_filas_consultas_total, tam_fila_triagem)

#função auxiliar que relaciona uma fila de critérios com as taxas e retorna as labels para os gráficos
def criterio_fTempo(tempos,lista_criterio, taxas):

    medias = []
    labels = []
    #cada posição é correspondente, porque a cada ciclo, o t_atual vai para a lista tempos e o correspondente tamanho da fila vai para tm_filas
    for t_inicial, t_final, tax in taxas:

        valores = [tam for t,tam in zip(tempos,lista_criterio) if t_inicial <= t < t_final]#zip pega em cada elemento de mesma posição e cria um tuplo, exemplo: nums = [1,2,3,4], letras = ["a","b","c","d"]
                                                                                                #exemplo: nums = [1,2,3,4], letras = ["a","b","c","d"]
                                                                                                #list(zip(nums,letras)) = [(1,"a"),(2,"b")...]
        medias.append(sum(valores)/len(valores) if valores else 0)
        labels.append(f"{t_inicial}-{t_final}\nλ={tax:.2f}")
    
    return medias,labels

#gráfico do tamanho médio das filas consultas em função das taxas de chegada
def tam_filasconsultas_VS_taxa(tempos,tam_filas_consultas_total, taxas):

    medias,labels = criterio_fTempo(tempos,tam_filas_consultas_total, taxas)

    plt.figure(figsize= (14,7))
    barras=plt.bar(labels,medias, color = "#429c91" )
    labels = [f"{med:.2f}" for med in medias]
    plt.bar_label(barras,labels=labels,padding=3)
    plt.xlabel("Taxas de chegada por intervalo de tempo (nº de pessoas/hora)")
    plt.ylabel("Tamanho médio das filas para as consultas (nº de pessoas)")
    plt.title("Evolução do tamanho médio das filas para as consultas em função da taxa de chegada")
    plt.grid(True,which="major", color="#b5b4b4",alpha=0.5,linewidth=0.7,linestyle="--")
    plt.tight_layout()
    plt.show()

    return

#tam_filasconsultas_VS_taxa(tempos,tam_filas_consultas_total, taxas)

# tamanho médio fila de triagem em função das taxas de chegada
def tam_filatriagem_VS_taxa(tempos,tam_fila_triagem, taxas):

    medias,labels = criterio_fTempo(tempos,tam_fila_triagem, taxas)

    plt.figure(figsize= (14,7))
    barras=plt.bar(labels,medias, color = "#429c91" )
    labels = [f"{med:.2f}" for med in medias]
    plt.bar_label(barras,labels=labels,padding=3)
    plt.xlabel("Taxas de chegada por intervalo de tempo (nº de pessoas/hora)")
    plt.ylabel("Tamanho médio da fila para a triagem (nº de pessoas)")
    plt.title("Evolução do tamanho médio das filas para a triagem em função da taxa de chegada")
    plt.grid(True,which="major", color="#b5b4b4",alpha=0.5,linewidth=0.7,linestyle="--")
    plt.tight_layout()
    plt.show()

    return

#tam_filatriagem_VS_taxa(tempos,tam_fila_triagem, taxas)

# média da taxa de ocupação dos médicos em função da taxa de chegada
def taxa_ocupacao_VS_taxas(tempos, ocup_med, taxas):

    medias,labels = criterio_fTempo(tempos,ocup_med, taxas)

    plt.figure(figsize= (14,7))
    barras=plt.bar(labels,medias, color = "#429c91" )
    labels = [f"{med:.2f}" for med in medias]
    plt.bar_label(barras, labels=labels,padding=3)
    plt.xlabel("Taxas de chegada por intervalo de tempo")
    plt.ylabel("Taxa média de ocupação dos médicos (%)")
    plt.title("Evolução da taxa de ocupação média dos médicos em função da taxa de chegada")
    plt.grid(True,which="major", color="#b5b4b4",alpha=0.5,linewidth=0.7,linestyle="--")
    plt.tight_layout()
    plt.show()

    return

#taxa_ocupacao_VS_taxas(tempos, ocup_med, taxas)

# evolução da taxa de ocupação ao longo do tempo
def taxa_ocupacao_VS_tempo(tempos,ocup_med):

    plt.figure(figsize=(12,6))
    plt.plot(tempos,ocup_med,marker=".",linestyle="-",color ="#429c91", linewidth=1.0)
    plt.title("Evolução da taxa de ocupação dos médicos em função do tempo ")
    plt.xlabel("Tempo (min)")
    plt.ylabel("Taxa de ocupação média dos médicos(%)")
    plt.xlim(0, 720)
    max_y = int(max(ocup_med)) + 2
    plt.yticks(range(0, max_y, 5))
    plt.xticks(range(0,721,60))
    plt.grid(True)
    plt.show()

    return

#taxa_ocupacao_VS_tempo(tempos,ocup_med)

#--------------------GERAR GRÁFICOS----------------------
def mostrar_graficos_finais(resultados):
    tempos = resultados["tempos"]
    tam_fila_triagem = resultados["tam_fila_triagem"]
    tam_filas_consultas_total = resultados["tam_filas_consultas_total"]
    tam_filas_consultas = resultados["tam_filas_consultas"]
    ocup_med = resultados["ocupacao_medicos"]
    medicos = resultados["medicos"]
    doentes_atendidos = resultados["doentes_atendidos"]
    taxas = resultados["taxas"]
    
    n = min(len(tempos), len(tam_fila_triagem))

    tempos_plot = tempos[:n]
    fila_plot = tam_fila_triagem[:n]

    tempo_medio_espera_doente(tempos, tam_fila_triagem)

    tam_filas_VS_tempo(tempos,tam_filas_consultas_total,tam_fila_triagem)

    taxa_ocupacao_VS_tempo(tempos,ocup_med)

    doentes_atendidos_por_medico(medicos)

    tempo_total_ocupado_medicos(medicos)

    grafico_estado_final(doentes_atendidos)

    grafico_media_tams_filasconsultas((tam_filas_consultas))

    tam_filasconsultas_VS_taxa(tempos,tam_filas_consultas_total,taxas)

    tam_filatriagem_VS_taxa(tempos,tam_fila_triagem,taxas)

    taxa_ocupacao_VS_taxas(tempos,ocup_med,taxas)
    
    return
