
#-----FICHEIRO DE CONFIGURAÇÕES DEFAULT DA CLÍNICA QUE É CHAMADO EM INTERFACE_CONFIG.PY

def config_default():
    return{
        "nbalcoes": 5,
        "nbalcoes_prior": 2,
        "modo":"Default",
        "taxas": [(0, 2 * 60, 20*4/ 60),
        (2 * 60, 4 * 60, 14*4 / 60),
        (4 * 60, 7 * 60, 9*4/ 60),
        (7 * 60, 9 * 60, 11*4/ 60),
        (9 * 60, 12 * 60, 19*4 / 60)]
    }
