import interface_Clinica as TI
import interface_Config as IC
import FreeSimpleGUI as sg


#-------FICHEIRO PARA INTERFACE DO MENU------

PRIMARY = "#429c91"
BG = "#9aa3ad"

modos_taxas={
        "Calmíssimo":[  
        (0, 2 * 60, 20*0.5/ 60),
        (2 * 60, 4 * 60, 14*0.5/ 60),
        (4 * 60, 7 * 60, 9*0.5/ 60),
        (7 * 60, 9 * 60, 11*0.5/ 60),
        (9 * 60, 12 * 60, 19*0.5/ 60)],
        "Calmo":[  
        (0, 2 * 60, 20/ 60),
        (2 * 60, 4 * 60, 14 / 60),
        (4 * 60, 7 * 60, 9/ 60),
        (7 * 60, 9 * 60, 11/ 60),
        (9 * 60, 12 * 60, 19/ 60)],
        "Default":[  
        (0, 2 * 60, 20*2/ 60),
        (2 * 60, 4 * 60, 14*2 / 60),
        (4 * 60, 7 * 60, 9*2/ 60),
        (7 * 60, 9 * 60, 11*2/ 60),
        (9 * 60, 12 * 60, 19*2 / 60)],
        "Cheio":[ 
        (0, 2 * 60, 20*5/ 60),
        (2 * 60, 4 * 60, 14*5 / 60),
        (4 * 60, 7 * 60, 9*5/ 60),
        (7 * 60, 9 * 60, 11 *5/ 60),
        (9 * 60, 12 * 60, 19*5 / 60)],
        "Cheiíssimo" :[ 
        (0, 2 * 60, 20*10/ 60),
        (2 * 60, 4 * 60, 14*10 / 60),
        (4 * 60, 7 * 60, 9*10/ 60),
        (7 * 60, 9 * 60, 11 *10/ 60),
        (9 * 60, 12 * 60, 19*10 / 60)]
    }

config_atual = {"taxas":modos_taxas["Default"],
              "nbalcoes":5,
              "nbalcoes_prior":2}

def interface_Menu():


    menu_layout=[
        [sg.Text("CLÍNICA SAÚDE", text_color= "white", font =("Inter",18,"bold"), justification = "center", expand_x=True, background_color="#234C4C")],
        [sg.VPush()],
        [sg.Button("⚙ CONFIGURAÇÕES", key = "-CONF-", size = (25,2), button_color=("white",PRIMARY))],
        [sg.Button("▶ INICIAR SIMULAÇÃO", key = "-PLAY-", size=(25,2), button_color=("white",PRIMARY))],
        [sg.Button("ℹ Ajuda", key="-HELP-", size=(25,2),button_color=("white",PRIMARY))],
        [sg.Button("❌ Sair",key="-EXIT-",size=(25,2),button_color=("white",PRIMARY))],
        [sg.VPush()]
    ]

    menu_window=sg.Window(
        "MENU CLÍNICA SAÚDE",
        menu_layout,
        finalize = True,
        element_justification="center",
        background_color="#234C4C"
    )

    STOP = False

    while not STOP:

        event,values = menu_window.read()

        if event== "-EXIT-" or event == sg.WINDOW_CLOSED:
            STOP = True
            menu_window.close()

        if event =="-PLAY-":
            menu_window.close()
            layout,cadeiras =TI.simulacao_principal(config_atual)
            #TI.run_simulacao(layout, cadeiras)
            STOP = True
        
        if event =="-CONF-":
            IC.interface_Config(config_atual,modos_taxas)

        if event =="-HELP-":
            interface_Ajuda(BG,PRIMARY)

    menu_window.close()

#------------------
#AJUDA
#------------------

def interface_Ajuda(BG,PRIMARY):

    ajuda_layout=[
        [sg.Text("AJUDA- FUNCIONAMENTO CLÍNICA SAÚDE",text_color="white", font= ("Inter",18,"bold"), justification="center", expand_x=True,background_color="#234C4C")],
        [sg.HorizontalSeparator()],
        [sg.Multiline("""
Esta aplicação simula o funcionamento de uma clínica de saúde.

--> Fluxo de pacientes na triagem:

- Entram na clínica;
- São separados em 2 filas de espera para a triagem: uma fila prioritária, e uma fila não prioritária;
- Os pacientes com consulta marcada têm prioridade na fila de espera sem prioridade;
- São atendidos em balcões, prioritários e não prioritários, e de seguida, encaminhados para filas de espera para os consultórios.
- As filas para os consultórios estão separadas por especialidades.
                
--> Fluxo de pacientes nas filas para os consultórios:

- Os pacientes com consulta têm prioridade nas filas para os consultórios;
- Cada especialidade tem um número de consultórios igual ao número de medicos da especialidade;
- Um paciente é atedido num consultório assim que um médico esteja disponível;
- Os médicos estão indisponiveis quando estão a atender um doente ou estão fora do turno de trabalho.
                      
--> Interface de simulação:
                      
- O horário de funcionamento da clínica é de cerca de 12 horas (se um paciente for atendido em antes do fecho da clínica, o consultório ainda está funcional até ao fim da consulta);
- O relógio mostra as horas e minutos do momento atual;
- A cor verde indica disponibilidade;
- A cor cinzenta indica fora de tempo de funcionamento;
- A cor vermelha indica ocupação;
- Uma especialidade fica vermelha se todos os consultórios estiverem indisponíveis, e fica verde se, pelo menos, 1 consultório estiver disponível;
- Ao clicar na especialidade, serão listados todos os consultórios e respetivo estado atual;
- Ao cicar nos consultórios, serão mostrados todos os dados e critérios atuais do respetivo consultório;
- Ao clicar nos diferentes elementos do layout, serão listados os dados e critérios atuais do respetivo item. 
                      
--> Menu Configurações:
                      
- Quando interage com o botão configurações, tem a opção de alterar o número de balcões total, o número de balcões prioritários e a taxa de chegada de doentes à clínica;
- Quando seleciona um número de balcões prioritários maior do que o número de balcões totais (balcões totais = balcões prioritários + número de balcões não prioritários), o programa vai dar erro, e os parâmetros da simulação vão ser os default (5 balcões totais, 2 balcões prioritários, modo Default de chegadas);
- A seleção da taxa está dividida modos: Calmíssimo, Calmo, Default, Cheio e Cheiíssimo. Esta variação é refletida na chegada de pacientes.

--> Objetivo da simulação:
                      
- Avaliar tamanhos e tempos médios de fila de espera, ocupação de recursos e avaliação da eficiência da clínica em função das taxas de chegada de doentes.
                      

Projeto académico - Algoritmos e técnicas de Programação - Licenciatura em Engenharia Biomédica (2025/2026)
Criadores: Cláudia Teixeira (A110414) e Fernando Costa (A110808)
""",
    size = (60,18),
    disabled = True,
    background_color="#AADADA")],

    sg.VPush(),
    sg.Button("⬅ VOLTAR AO MENU", key="-BACK-", size =(20,1),button_color=("white", PRIMARY))],

    ajuda_window = sg.Window(
        "Ajuda",
        ajuda_layout,
        modal = True, #bloqueia a interação com as outras janelas enquanto está ativa
        finalize = True, #permite mudar a janela (update) em antes de esta estar pronta/invocada
        element_justification= "center",
        background_color="#234C4C"
    )

    STOP = False

    while not STOP:

        event,values=ajuda_window.read()

        if event == "-BACK-" or event == sg.WINDOW_CLOSED:
            STOP = True

    ajuda_window.close()
