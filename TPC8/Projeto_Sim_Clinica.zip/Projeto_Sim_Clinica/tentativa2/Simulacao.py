import random
import Triagem as tr
import Chegadas as ch
import Consultorios as con
import numpy as np


#FICHEIRO DE EXTREMA RELEVÂNCIA!!!

#----------FICHEIRO QUE ORGANIZA OS EVENTOS E FAZ A SIMULAÇÃO FUNCIONAR------

#---------------------Carregamento de ficheiros e condições de início--------------------
    
def simulação(config_atual):
    t_atual= 0.0
    tfinal = 12*60  #12 horas de funcionamento
    eventos = []
    doentes_atendidos = []

    #Tipos de eventos: "CHEGADA", "ENTRA_TRIAGEM", "SAI_TRIAGEM", "ENTRA_CONSULTORIO", "SAI_CONSULTORIO"

    doentes = tr.Doentes("./tentativa2/pessoas_corrigido.json")
    medicos = con.carregaMedicos("./tentativa2/medicos.json")

    
    taxas = config_atual["taxas"]

    def defineTaxas(taxas):
        return taxas
    
        

    fila_triagem = [[], []]   # [prioritarios, resto]

    balcoes = tr.criaBalcoes(config_atual)
        
    filas_consultas = {
    "Dermatologia": {"com_consulta": [], "sem_consulta": []},
    "Gastroenterologia": {"com_consulta": [], "sem_consulta": []},
    "Pneumonologia": {"com_consulta": [], "sem_consulta": []},
    "Cardiologia": {"com_consulta": [], "sem_consulta": []},
    "Endocrinologia": {"com_consulta": [], "sem_consulta": []},
    "Ortopedia": {"com_consulta": [], "sem_consulta": []},
    "Neurologia": {"com_consulta": [], "sem_consulta": []},
    "Ginecologia e Obstetrícia": {"com_consulta": [], "sem_consulta": []},
    "Psiquiatria": {"com_consulta": [], "sem_consulta": []},
    "Pediatria": {"com_consulta": [], "sem_consulta": []},
    "Medicina Geral": {"com_consulta": [], "sem_consulta": []}
}

    seccoes = [{"especialidade": "Dermatologia", "id": "s1", "consultorios":[]},

            {"especialidade": "Gastroenterologia", "id": "s2", "consultorios":[]},
                                                                            
            {"especialidade": "Pneumonologia", "id": "s3", "consultorios":[]},
            
            {"especialidade": "Cardiologia", "id": "s4", "consultorios":[]},
            
            {"especialidade": "Endocrinologia", "id": "s5","consultorios":[]},
                                                                        
            {"especialidade": "Ortopedia", "id": "s6","consultorios":[]},
            
            {"especialidade": "Neurologia", "id": "s7","consultorios":[]},

            {"especialidade": "Ginecologia e Obstetrícia", "id": "s8","consultorios":[]},

            {"especialidade": "Psiquiatria", "id": "s9","consultorios":[]},

            {"especialidade": "Pediatria", "id": "s10","consultorios":[]},

            {"especialidade": "Medicina Geral", "id": "s11","consultorios":[]}]
    
    seccoes = con.criaConsultorios(medicos,seccoes)

    
    
    horarios = ch.janelas_funcionamentoEspecialidades(medicos)

    t_chegada = np.random.exponential(1/taxas[0][2])
    
    validado = False
    while not validado:
        i = random.randint(0, len(doentes)-1)
        candidato = doentes[i]

        if ch.chegada_valida(candidato, t_chegada, horarios):
        
            doente = doentes.pop(i)
            doente["tchegada"] = round(t_chegada,2)
            eventos.append({
            "tempo": round(t_chegada,2),
            "tipo": "CHEGADA",
            "doente": doente
            })
            validado = True
            doentes_atendidos.append(doente) #registo
            doente["estado_final"] = "FILA_TRIAGEM" #registo

    eventos.sort(key=lambda e: e["tempo"])

    #----------PARA GRÁFICOS------------
    tempos = []
    tam_fila_triagem = []
    tam_filas_consultas = {}
    tam_filas_consultas_total = []
    ocupacao_medicos = []



    while eventos and t_atual < tfinal:
        evento = eventos.pop(0)
        t_atual = evento["tempo"]
        doente = evento["doente"]
        
        #------REGISTO PARA GRÁFICOS--------

        #tamanho total da fila de triagem
        fila_total_triagem = len(fila_triagem[0]) + len(fila_triagem[1])

        #tamanho total das filas para as consultas
        tam_filas_consultas = con.tamanho_filas_cosultas(filas_consultas,tam_filas_consultas)
        tam_filas_consultas_total = con.tamanho_total_filasconsultas(filas_consultas,tam_filas_consultas,tam_filas_consultas_total)

        #médicos ocupados
        medicos_ocupados = sum(1 for m in medicos if m["doente"] is not None)
        taxa_ocupacao = (medicos_ocupados / len(medicos)) *100

        #guardar valores
        tempos.append(t_atual)
        tam_fila_triagem.append(fila_total_triagem)
        #tam_fila_consultas.append(fila_total_consultas)
        ocupacao_medicos.append(taxa_ocupacao)

        #----------------------


        if evento["tipo"] == "CHEGADA":
            #doente = evento["doente"] ###
            fila_triagem = tr.chegadaAntesTriagem(doente, fila_triagem)

            fila_triagem, balcoes, eventos_gerados = tr.ocupar_balcaoTriagem(fila_triagem, balcoes, t_atual)
            for evento in eventos_gerados:
                if evento != None:
                    eventos.append(evento)
            
            
            for tax in taxas:
                if t_atual >= tax[0] and t_atual <= tax[1]:
                    taxa_atual = tax[2]
            
            intervalo = np.random.exponential(1 / taxa_atual)
            proxima_chegada = t_atual + intervalo

            if proxima_chegada < tfinal and doentes:

                validado = False
                while not validado:
                    j = random.randint(0, len(doentes)-1)
                    candidato = doentes[j]

                    if ch.chegada_valida(candidato, proxima_chegada, horarios):

                        validado = True
                        novo_doente = doentes.pop(j)
                        novo_doente["tchegada"] = round(proxima_chegada,2)
                        eventos.append({
                        "tempo": round(proxima_chegada,2),
                        "tipo": "CHEGADA",
                        "doente": novo_doente
                        })
                        doentes_atendidos.append(doente) #registo
                        doente["estado_final"] = "FILA_TRIAGEM" #registo
                        
                eventos.sort(key=lambda e: e["tempo"])
                
            #for evento in eventos:
                #print(evento['tipo'], evento['tempo'], evento['doente']['nome'])


        elif evento["tipo"] == "SAI_TRIAGEM":

            balcoes,_ = tr.desocupar_balcaoTriagem(balcoes, t_atual)
            fila_triagem, balcoes, novos = tr.ocupar_balcaoTriagem(fila_triagem, balcoes, t_atual)
            for e in novos:
                if e:
                    eventos.append(e)


            esp = doente["especialidade"]
            if doente["consulta"]:
                filas_consultas[esp]["com_consulta"].append(doente)
            else:
                filas_consultas[esp]["sem_consulta"].append(doente)

            con.tentar_atribuir_fila(esp, filas_consultas, seccoes, eventos, t_atual)

            eventos.sort(key=lambda e: e["tempo"])

                
        elif evento["tipo"] == "SAI_CONSULTORIO":

            medico = evento["medico"]
            t_atual = evento["tempo"]

            con.desocuparMedico(medico, t_atual)

            esp = medico["especialidade"]
            con.tentar_atribuir_fila(esp, filas_consultas, seccoes, eventos, t_atual)

            eventos.sort(key=lambda e: e["tempo"])

  
        yield (
                t_atual,
                fila_triagem,
                filas_consultas,
                balcoes,
                medicos,
                seccoes,
                doentes_atendidos
            )


    return {
        
    "tempos": tempos,
    "tam_fila_triagem": tam_fila_triagem,
    "tam_filas_consultas_total": tam_filas_consultas_total,
    "tam_filas_consultas": tam_filas_consultas,
    "ocupacao_medicos": ocupacao_medicos,
    "fila_triagem": fila_triagem,
    "filas_consultas": filas_consultas,
    "medicos": medicos,
    "doentes_atendidos": doentes_atendidos,
    "taxas" : taxas
}


